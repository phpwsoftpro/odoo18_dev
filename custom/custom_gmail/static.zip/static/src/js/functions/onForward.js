/** @odoo-module **/

export function onForward(ev, msg) {
    ev.stopPropagation();

    const forwardedBody = `
        <br><br>---------- Forwarded message ---------<br>
        From: ${msg.author_name || msg.from || ''}<br>
        Date: ${msg.date || ''}<br>
        Subject: ${msg.subject || ''}<br>
        To: ${msg.to || ''}<br><br>
        ${msg.body || ''}
    `;

    this.openComposeModal("forward", {
        subject: `Fwd: ${msg.subject || ''}`,
        body: forwardedBody,
        attachments: msg.attachments || [],
        is_forward: true,
    });
}
