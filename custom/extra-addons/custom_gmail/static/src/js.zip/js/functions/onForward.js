/** @odoo-module **/

export function onForward(ev, msg) {
    ev.stopPropagation();

    const senderName = msg.author_name || msg.sender || '';
    const senderEmail = msg.from_email || '';  // bạn cần chắc có `msg.from_email`

    const dateStr = msg.date
        ? new Date(msg.date).toLocaleString('vi-VN')  // ví dụ: 26/07/2025, 08:44
        : '';

    const forwardedBody = `
        <br><br>---------- Forwarded message ---------<br>
        From: "${senderName}" &lt;${senderEmail}&gt;<br>
        Date: ${dateStr}<br>
        Subject: ${msg.subject || ''}<br>
        To: ${msg.to || ''}<br><br>
        ${msg.body || ''}
    `;


    this.openComposeModal("forward", {
        subject: `Fwd: ${msg.subject || ''}`,
        body: forwardedBody,
        attachments: msg.attachments || [],
        is_forward: true,
    });
}
